create
    definer = root@localhost procedure fiu(IN age int, OUT name varchar(255))
BEGIN
   SELECT * INTO name
   FROM users
   WHERE age = age;
END;

