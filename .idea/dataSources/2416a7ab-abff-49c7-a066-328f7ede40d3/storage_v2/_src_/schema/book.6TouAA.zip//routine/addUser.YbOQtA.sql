create
    definer = root@localhost procedure addUser(IN name varchar(50), IN age int)
begin
        INSERT INTO users (name, age) VALUES (name, age);
     end;

