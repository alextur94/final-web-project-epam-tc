create
    definer = root@localhost procedure sau()
begin
        SELECT * FROM users;
     end;

